console.log("Initializing Rushercrack...");
console.log("Once initialized, Rushercrack will being to exploit Rusherhack ports.");
console.log("This process may take a while on the first run.");
setTimeout(crack, 4500);
function crack() {
    for (;;)
    {
        console.log(Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15));
    }  
}