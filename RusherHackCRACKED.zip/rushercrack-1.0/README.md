# Rushercrack, the free open-source method to use Rusherhack for free

## Requirements
- Windows, Linux, or MacOS
- Git
- Node.js

## Installation and Execution
1) Clone the repository ``git clone https://github.com/7OU/rushercrack.git``
2) Open a terminal and goto the cloned repository
3) Run Rushercrack ``node rushercrack.js``
4) Wait until Rusherhack opens.
5) Profit.
